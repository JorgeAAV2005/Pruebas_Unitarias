from datetime import datetime
from mi_modulo import es_par, calcular_edad, generar_id, ordenar_por_longitud, Carrito, Inventario, CalculadoraDescuentos, SistemaAutenticacion, GestionTareas, SistemaReservas
import pytest

#EJERCICIO 1

def test_es_par():
    assert es_par(4) == True  
    assert es_par(7) == False  
    assert es_par(0) == True  
    assert es_par(-2) == True  


#EJERCICIO 2

def test_calcular_edad():
    assert calcular_edad("2000-01-01") == 24  
    assert calcular_edad("2024-01-01") == 0  
    assert calcular_edad("1990-09-28") == datetime.now().year - 1990
    with pytest.raises(ValueError):
        calcular_edad("2030-01-01") 


#EJERCICIO 3

def test_generar_id():
    id1 = generar_id()
    id2 = generar_id()
    assert len(id1) == 8
    assert id1.isalnum()
    assert id1 != id2  

#EJERCICIO 4

def test_ordenar_por_longitud():
    assert ordenar_por_longitud(["perro", "gato", "elefante"]) == ["gato", "perro", "elefante"]
    assert ordenar_por_longitud(["sol", "estrella", "luna"]) == ["sol", "luna", "estrella"]
    assert ordenar_por_longitud([]) == []
    assert ordenar_por_longitud(["sol", "sol", "sol"]) == ["sol", "sol", "sol"]

#EJERCICIO 5

def test_carrito():
    carrito = Carrito()
    carrito.agregar_producto("Producto1", 100)
    carrito.agregar_producto("Producto2", 50)
    assert carrito.calcular_total(0) == 150  
    assert carrito.calcular_total(10) == 135  
    assert carrito.calcular_total(100) == 0  

#EJERCICIO 6

def test_inventario():
    inventario = Inventario()
    
    inventario.agregar_producto(1, "Manzanas", 100)
    assert inventario.consultar_producto(1) == {"nombre": "Manzanas", "stock": 100}

    with pytest.raises(ValueError):
        inventario.agregar_producto(1, "Peras", 50)

    inventario.eliminar_producto(1)
    with pytest.raises(ValueError):
        inventario.consultar_producto(1) 

    with pytest.raises(ValueError):
        inventario.actualizar_stock(2, 50)


#EJERCICIO 7

def test_calculadora_descuentos():
    calculadora = CalculadoraDescuentos(100, 20)
    
    
    assert calculadora.calcular_precio_final() == 80
    
    
    calculadora_invalida = CalculadoraDescuentos(0, 20)
    with pytest.raises(ValueError):
        calculadora_invalida.validar_precio()

    
    calculadora_descuento_invalido = CalculadoraDescuentos(100, 110)
    with pytest.raises(ValueError):
        calculadora_descuento_invalido.validar_descuento()

#EJERCICIO 8

def test_sistema_autenticacion():
    sistema = SistemaAutenticacion()
    
    
    sistema.registrar_usuario("jorge", "password123")
    assert "jorge" in sistema.usuarios

    with pytest.raises(ValueError):
        sistema.registrar_usuario("jorge", "otraPassword")

    sistema.iniciar_sesion("jorge", "password123")
    assert sistema.usuarios["jorge"]["logged_in"] is True

    with pytest.raises(ValueError):
        sistema.iniciar_sesion("jorge", "incorrecta")
 
    sistema.cerrar_sesion("jorge")
    assert sistema.usuarios["jorge"]["logged_in"] is False

    with pytest.raises(ValueError):
        sistema.recuperar_contrasena("inexistente")

#EJERCICIO 9

def test_gestion_tareas():
    tareas = GestionTareas()
    
    tareas.crear_tarea("Estudiar", "2024-09-30")
    assert len(tareas.tareas) == 1

    tareas.marcar_completada("Estudiar")
    assert tareas.tareas[0]["completada"] is True

    with pytest.raises(ValueError):
        tareas.marcar_completada("No existe")

    tareas.eliminar_tarea("Estudiar")
    assert len(tareas.tareas) == 0

    with pytest.raises(ValueError):
        tareas.eliminar_tarea("No existe")

#EJERCICIO 10

def test_sistema_reservas():
    reservas = SistemaReservas()

    reservas.crear_reserva("jorge", "2024-09-30", "19:00", 4)
    assert len(reservas.reservas) == 1

    assert reservas.verificar_disponibilidad("2024-09-30", "19:00") is False

    reservas.cancelar_reserva("jorge", "2024-09-30", "19:00")
    assert len(reservas.reservas) == 0

    with pytest.raises(ValueError):
        reservas.cancelar_reserva("jorge", "2024-09-30", "19:00")

    assert reservas.verificar_disponibilidad("2024-09-30", "19:00") is True